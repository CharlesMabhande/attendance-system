from django.shortcuts import render, redirect, HttpResponse, redirect
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from .models import *
from .forms import *
import face_recognition
import cv2
import numpy as np
from django.db.models import Q
import os
from django.shortcuts import render, redirect
from django.contrib import messages
import pyzbar.pyzbar as pyzbar
from pyzbar.pyzbar import decode 
from datetime import date
from django.http import HttpResponse
import qrcode
from .models import Profile  
from django.shortcuts import render, redirect, get_object_or_404
from .models import QRCode



def loginUser(request):
    page = 'login'
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']

        user = authenticate(request, username=username, password=password)

        if user is not None:
            login(request, user)
            return redirect('index')

    return render(request, 'Attendance/login_register.html', {'page': page})


def logoutUser(request):
    logout(request)
    return redirect('login')

def registerUser(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('login')
    else:
        form = UserCreationForm()
    context = {'form': form}
    return render(request, 'Attendance/login_register.html', context)

    
last_face = 'no_face'
current_path = os.path.dirname(__file__)
sound_folder = os.path.join(current_path, 'sound/')
face_list_file = os.path.join(current_path, 'face_list.txt')
sound = os.path.join(sound_folder, 'beep.wav')


@login_required(login_url='login')
def index(request):
    scanned = LastFace.objects.all().order_by('date').reverse()
    present = Profile.objects.filter(
        present=True).order_by('updated').reverse()
    absent = Profile.objects.filter(present=False).order_by('shift')
    context = {
        'scanned': scanned,
        'present': present,
        'absent': absent,
    }
    return render(request, 'Attendance/index.html', context)


@login_required(login_url='login')
def ajax(request):
    last_face = LastFace.objects.last()
    context = {
        'last_face': last_face
    }
    return render(request, 'Attendance/ajax.html', context)


@login_required(login_url='login')
def scan(request):

    global last_face

    known_face_encodings = []
    known_face_names = []

    profiles = Profile.objects.all()
    for profile in profiles:
        person = profile.image
        image_of_person = face_recognition.load_image_file(f'media/{person}')
        person_face_encoding = face_recognition.face_encodings(image_of_person)[
            0]
        known_face_encodings.append(person_face_encoding)
        known_face_names.append(f'{person}'[:-4])

    video_capture = cv2.VideoCapture(0)

    face_locations = []
    face_encodings = []
    face_names = []
    process_this_frame = True

    while True:

        ret, frame = video_capture.read()
        small_frame = cv2.resize(frame, (0, 0), fx=0.25, fy=0.25)
        rgb_small_frame = small_frame[:, :, ::-1]

        if process_this_frame:
            face_locations = face_recognition.face_locations(rgb_small_frame)
            face_encodings = face_recognition.face_encodings(
                rgb_small_frame, face_locations)

            face_names = []
            for face_encoding in face_encodings:
                matches = face_recognition.compare_faces(
                    known_face_encodings, face_encoding)
                name = "Unknown"

                face_distances = face_recognition.face_distance(
                    known_face_encodings, face_encoding)
                best_match_index = np.argmin(face_distances)
                if matches[best_match_index]:
                    name = known_face_names[best_match_index]

                    profile = Profile.objects.get(Q(image__icontains=name))
                    if profile.present == True:
                        pass
                    else:
                        profile.present = True
                        profile.save()

                    if last_face != name:
                        last_face = LastFace(last_face=name)
                        last_face.save()
                        last_face = name
                    else:
                        pass

                face_names.append(name)

        process_this_frame = not process_this_frame

        for (top, right, bottom, left), name in zip(face_locations, face_names):
            top *= 4
            right *= 4
            bottom *= 4
            left *= 4

            cv2.rectangle(frame, (left, top), (right, bottom), (0, 0, 255), 2)

            cv2.rectangle(frame, (left, bottom - 35),
                          (right, bottom), (0, 0, 255), cv2.FILLED)
            font = cv2.FONT_HERSHEY_DUPLEX
            cv2.putText(frame, name, (left + 6, bottom - 6),
                        font, 0.5, (255, 255, 255), 1)

        cv2.imshow('Video', frame)

        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    video_capture.release()
    cv2.destroyAllWindows()
    return HttpResponse('scaner closed', last_face)



import cv2
import pyzbar.pyzbar as pyzbar
from django.shortcuts import render
from .models import Profile, LastFace, QRCode

@login_required(login_url='login')
def scan_qr(request):
    # Load the QR code scanner
    cap = cv2.VideoCapture(0)
    font = cv2.FONT_HERSHEY_PLAIN

    # Create a list to store the students who have attended
    attendance = []

    while True:
        # Capture an image from the camera
        _, frame = cap.read()

        # Decode the QR code in the image
        decoded_objects = pyzbar.decode(frame)

        # Loop through each decoded object
        for obj in decoded_objects:
            # Check if the decoded object is a QR code
            if obj.type == 'QRCODE':
                # Get the content of the QR code
                content = obj.data.decode()

                # Get the profile associated with the QR code
                try:
                    profile = Profile.objects.get(Roll_Number=content)
                except Profile.DoesNotExist:
                    # If the profile does not exist, skip this QR code
                    continue

                # If the student has not already attended, mark them as present
                if not profile.present:
                    profile.present = True
                    profile.save()
                    attendance.append(profile)

        # Display the attendance on the screen
        cv2.putText(frame, f"Attendance: {len(attendance)}", (10, 50), font, 2, (0, 255, 0), 2, cv2.LINE_AA)

        # Display the image on the screen
        cv2.imshow("Image", frame)

        # Wait for a key to be pressed
        key = cv2.waitKey(1)

        # If the 'q' key is pressed, stop capturing
        if key == ord('q'):
            break

    # Release the camera and close the window
    cap.release()
    cv2.destroyAllWindows()

    # Return the attendance as a response
    return render(request, 'Attendance/index.html', {'attendance': attendance})


@login_required(login_url='login')
def profiles(request):
    profiles = Profile.objects.all()
    context = {
        'profiles': profiles
    }
    return render(request, 'Attendance/profiles.html', context)
    

@login_required(login_url='login')
def details(request):
    try:
        last_face = LastFace.objects.last()
        profile = Profile.objects.get(Q(image__icontains=last_face))
    except:
        last_face = None
        profile = None

    context = {
        'profile': profile,
        'last_face': last_face
    }
    return render(request, 'Attendance/details.html', context)
    
import qrcode

from .models import Profile
@login_required(login_url='login')
def generate_qrcode(request):
    # Get all student profiles from the database
    students = Profile.objects.filter(status='Student')

    for student in students:
        # Create a QR code with the student's name and Roll_Number as its content
        content = f"{student.first_name} {student.last_name} ({student.Roll_Number})"
        qr_code = qrcode.make(content)

        # Save the QR code to the database
        qr_code_model = QRCode.objects.create(image=qr_code, content=content)
        student.qr_code = qr_code_model
        student.save()

    return HttpResponse("QR codes generated and saved!")

import qrcode
import os
from django.conf import settings
from django.http import HttpResponse
from django.shortcuts import render, redirect
from .models import Profile

#worked once
@login_required(login_url='login')
def create_qr_codes(request):
    profiles = Profile.objects.all()  # get all profiles
    for profile in profiles:
        # create a QR code for each profile
        qr = qrcode.QRCode(version=1, error_correction=qrcode.constants.ERROR_CORRECT_L, box_size=10, border=4)
        qr.add_data(profile.Roll_Number)
        qr.make(fit=True)
        img = qr.make_image(fill_color="black", back_color="white")
        # save QR code as image in the qrcodes folder
        filepath = os.path.join(settings.MEDIA_ROOT, 'qrcodes', f"{profile.Roll_Number}.png")
        img.save(filepath)
        # save the QR code filepath to the database
        profile.qrcode_file = os.path.join('qrcodes', f"{profile.Roll_Number}.png")
        profile.save()
    return HttpResponse("QR codes generated successfully!")

import os
import qrcode
from django.shortcuts import render
from Attendance.models import Profile
import qrcode
import os
from django.shortcuts import render
from django.http import HttpResponse
from .models import Profile


import qrcode
import os
from django.conf import settings
from django.http import HttpResponse

@login_required(login_url='login')
def generate_qr_codes(request):
    profiles = Profile.objects.all()
    for profile in profiles:
        qr = qrcode.QRCode(version=1, box_size=10, border=5)
        qr.add_data(profile.QR_code)
        qr.make(fit=True)
        img = qr.make_image(fill='black', back_color='white')
        filename = profile.first_name + profile.last_name + '_QR.png'
        filepath = os.path.join(settings.QR_CODE_DIR, filename)
        img.save(filepath, format='PNG')
    return HttpResponse('<h1>QR codes generated</h1>')



@login_required(login_url='login')
def add_profile(request):
    form = ProfileForm
    if request.method == 'POST':
        form = ProfileForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('profiles')
    context = {'form': form}
    return render(request, 'Attendance/add_profile.html', context)


@login_required(login_url='login')
def edit_profile(request, id):
    profile = Profile.objects.get(id=id)
    form = ProfileForm(instance=profile)
    if request.method == 'POST':
        form = ProfileForm(request.POST, request.FILES, instance=profile)
        if form.is_valid():
            form.save()
            return redirect('profiles')
    context = {'form': form}
    return render(request, 'Attendance/add_profile.html', context)


@login_required(login_url='login')
def delete_profile(request, id):
    profile = Profile.objects.get(id=id)
    profile.delete()
    return redirect('profiles')


@login_required(login_url='login')
def clear_history(request):
    history = LastFace.objects.all()
    history.delete()
    return redirect('index')


@login_required(login_url='login')
def reset(request):
    profiles = Profile.objects.all()
    for profile in profiles:
        if profile.present == True:
            profile.present = False
            profile.save()
        else:
            pass
    return redirect('index')
