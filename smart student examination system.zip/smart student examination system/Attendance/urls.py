from django.urls import path,include
from .views import *
from.import views
from .models import Profile
from .views import profiles

urlpatterns = [
    path('', views.loginUser, name ="login"),
    path('logout/', views.logoutUser, name ="logout"),
    path('register/', views.registerUser, name ="register"),
    path('index/', index, name= 'index'),
    path('ajax/', ajax, name= 'ajax'),
    path('scan/',scan,name='scan'),
    path('profiles/', profiles, name= 'profiles'),
    path('details/', details, name= 'details'),
    path('add_profile/',add_profile,name='add_profile'),
    path('edit_profile/<int:id>/',edit_profile,name='edit_profile'),
    path('delete_profile/<int:id>/',delete_profile,name='delete_profile'),
    path('clear_history/',clear_history,name='clear_history'),
    path('reset/',reset,name='reset'),
    path('scan_qr/', scan_qr, name='attend_scan'),
    #path('generate_qrcode/', views.generate_qrcode, name='generate_qrcode'),
    path('generate_qr_codes/', views.create_qr_codes, name='generate_qr_codes'),
    path('profiles/', profiles, name='profiles'),


]



